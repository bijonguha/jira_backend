import os
from enum import Enum

class Constants(Enum):

    LOGS_FOLDER = "logs"
    LOGS_FILE = "grollm.log"
    LOG_LEVEL = "DEBUG"
